
const { EmbedBuilder,PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle  } = require("discord.js");
const { Command } = require("../../../../Global/Structures/Default.Commands");
const { post } = require("node-superfetch");
const {Guild} = require("../../../../Global/Config/Guild")
const User = require("../../../../Global/Database/Users")
class template extends Command {
    constructor(client) {
        super(client, {
            name: "",
            description: "",
            usage: "",
            category: "",
            aliases: [""],

            enabled: true,

            permissions: ["755814520009523301","755814520009523301", PermissionsBitField.Flags.Administrator,"755814520009523301"],
        });
    }
    

    onLoad(client) {
    
    }

 async onRequest (client, message, args,embed) {
    let member = message.mentions.members.first() || message.guild.members.cache.get(args[0])

}
}
module.exports = template;