﻿module.exports = {
    Guild:{
        Bots:{
            mainToken:"ODgwNDM3MTY4NzY0NTE0MzA1.GKPNAl.or7ut98ycFBTTqEEq_OwWJXAT4KUU0LteREl_E",
            statToken:"ODgwNTU2ODQzNjI0MTkwMDI0.GsRVyv.AOsdled_PHtK-DMmvd4kJSx_GtvBPF0J1-Gjrc",
            ProsecutorToken:"ODgwNTI1NTY1MTA1NDM0NjQ1.G-zFYe.yEx_wjNtWCF_7ZHhrPuV8qYCVSbFP6162DsTnE",
            guardOne: "ODgyMjQ1OTA3OTkzNzM1MTY5.GhcRbn.rWyulOhFMr3nrDKbUJGV3k0TnXwtT4xuabmfxA",
            guardTwo:"ODg1MDc5NTI3NDY0Nzk2MTcy.GaL3UY.RN4viS1pKu3_S__z0vPyt-WEzvCCOUOZlHhtkc",
            guardThree:"ODg2NjQ1MDMxNzgyNDY1NTk2.GjHLyK.-CPhru6MJAHdzCmj53KpIErYgMjUJWUe4a2Bnc",
            MongoDb:"mongodb+srv://Chvdev:chvdev159@chvdev.oxb17al.mongodb.net/?retryWrites=true&w=majority&appName=Chvdev",
            prefixs:["."],
            devs:["335707525552799747","755814520009523301","1143125805438881832"],
            Dis:[
"ODgwNTM1NzYxMjY5NzEwODg4.G2HRI5.jolC8D9MSzNVBYE_stwwepwYBkLjn-9pYpNCz8",
"ODgwNTM1ODA4Nzk5NTU1NjE0.GUAMTC.GgaT5_u0JuBwpBoZwDzifD4jaJA3dv32tuVLCU",
"ODgwNTM1ODUxOTY3MzMyNDI0.Gfj6Ut.2Jqm6_fhkKnODckKrbc4JE7wbCMy8qZzYq5Zuk",
"ODgwNTU0ODUwNDI4MDE0Njky.GTXkKK.YnuDcqJALTAQWTYAt2bgJMgd4UakxLL2npEzgE"
            ]
        },
        ID:"1221368315042070538",
        vanityURL:"merlin",
        botVoiceChannel:"1238120177657450516",
        botStatus:"Fexy 🖤 ★ Merlin ",
        welcomeVoiceLink:[
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952618328555640/Sanser_-_Ne_Icin_Yasyorum_feat_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952618047549561/Sanser_-_Ne_Icin_Yasyorum_feat_mp3cut.net_2.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952617770721300/Sanser_-_Ne_Icin_Yasyorum_feat_mp3cut.net_1.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952617502277713/Sandn_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952617238048900/Sagopa_Kajmer_Galiba_Video_Klip_Full_Kalite_mp3cut.netd.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952616915083294/Sagopa_Kajmer_Galiba_Video_Klip_Full_Kalite_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952616520822834/Sagopa_Kajmer_-_366_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952616143331469/MOTIVE_-_MASAL_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952615820361759/MOTIVE_-_10_MG_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952615484829748/Gripin_-_Ask_Nereden_Nereye_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952617376460880/Geceler_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952616780877985/ERO_-_VVS__Official_Music_Video__mp3cut.net1.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952616223023197/ERO_-_VVS__Official_Music_Video__mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952615916843070/DEHA_INC_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051952615585501235/ARASAN_DA_mp3cut.net.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051957612150800404/Muslum_Gurses_-_Unutamadm_mp3cut.net_1.mp3",
        "https://cdn.discordapp.com/attachments/969237463782543410/1051957612737990676/Muslum_Gurses_-_Unutamadm_mp3cut.net.mp3"
        ],
    StaffAutoRank:{
    1:{Role:"",Powers:[""], AMP:0,Missions:{V:3600000,M:100,R:10,I:10,TI:5,SI:3}},
    1:{Role:"",Powers:[""], AMP:200,Missions:{V:3600000,M:100,R:10,I:10,TI:5,SI:3}},
    1:{Role:"",Powers:[""], AMP:400,Missions:{V:3600000,M:100,R:10,I:10,TI:5,SI:3}},

    1:{Role:"",Powers:[""], AMP:600,Missions:{V:3600000*2,M:100*2,R:10*2,I:10*2,TI:5*2,SI:3*2}},
    1:{Role:"",Powers:[""], AMP:800,Missions:{V:3600000*2,M:100*2,R:10*2,I:10*2,TI:5*2,SI:3*2}},
    1:{Role:"",Powers:[""], AMP:1000,Missions:{V:3600000*2,M:100*2,R:10*2,I:10*2,TI:5*2,SI:3*2}},
    2:{Role:"",Powers:["",""], AMP:200,Missions:{V:3600000*2,M:100*2,R:10*2,I:10*2,TI:5*2,SI:5*2}}
}
  }
};